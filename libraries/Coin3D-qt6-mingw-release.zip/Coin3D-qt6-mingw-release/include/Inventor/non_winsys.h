#ifndef COIN_NON_WINSYS_H
#define COIN_NON_WINSYS_H

/* compatibility header */

#endif // !COIN_NON_WINSYS_H
