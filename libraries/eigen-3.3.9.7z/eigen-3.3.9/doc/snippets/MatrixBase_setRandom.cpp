Matrix4i m = Matrix4i::Zero();
m.col(1).setRandom();
cout << m << endl;
