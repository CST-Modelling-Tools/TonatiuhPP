#ifndef COIN_OIVWIN32_H
#define COIN_OIVWIN32_H

/* compatibility header */

#include <windows.h>
#include <winsock.h>

#endif // !COIN_OIVWIN32_H
