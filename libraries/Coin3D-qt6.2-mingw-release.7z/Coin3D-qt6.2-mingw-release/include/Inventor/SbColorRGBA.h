#ifdef COIN_INTERNAL
#error do not use this header internally
#endif // COIN_INTERNAL

#include <Inventor/SbColor4f.h>
